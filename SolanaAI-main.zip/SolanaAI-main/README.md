# SolanaAI
Some Idiot thought he can take my work and just sell it without my part. so here you go try selling now dumbass



For the Arduino + Hostshield you require a logitech or Razer mouse, that dumbass couldnt even manage to share the same source he stole from Lunar,
so besides that you gotta press the reset button on your arduino as soon as you open fz.exe

after that check in device manager if your Com port is gone and HID is there.


(oh yea dumbwit nice try trying to activate the blocker through your hidden code, im not an idiot, its already deleted)
